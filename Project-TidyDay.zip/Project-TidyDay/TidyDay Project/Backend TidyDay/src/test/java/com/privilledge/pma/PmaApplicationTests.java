package com.privilledge.pma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
