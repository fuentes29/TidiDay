export const setEmail = (email) => ({
  type: "SET_EMAIL",
  payload: email,
});
export const setUserName = (username) => ({
  type: "SET_USERNAME",
  payload: username,
});
